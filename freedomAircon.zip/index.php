<?php
clearstatcache();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Freedom AirCon Jaipur</title>
    <?php include 'common/head.php' ?>
</head>

<body>
  
<?php include 'common/navbar.php'  ?>

    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/carousel-1.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 pt-5">
                                    <h1 class="display-4 text-white mb-4 animated slideInDown">We Provide Best AC Repair Services</h1>
                                    <p class="fs-5 text-white  mb-4 pb-2 mx-sm-5 animated slideInDown">Our team is dedicated to ensuring your comfort and satisfaction. With years of experience, we guarantee top-notch AC repair services tailored to your needs.</p>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/carousel-2.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 pt-5">
                                    <h1 class="display-4 text-white mb-4 animated slideInDown">Quality Air Condition Services</h1>
                                    <p class="fs-5 text-white mb-4 pb-2 mx-sm-5 animated slideInDown">At our company, we prioritize your comfort and satisfaction above all else. With our expert team, you can trust that your heating and air conditioning systems are in good hands.</p>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Carousel End -->


    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="h-100">
                        <h1 class="display-6 mb-5">Welcome To Best Cooling & Heating Service Center</h1>
                        <div class="row g-4 mb-4">
                            <div class="col-sm-6">
                                <div class="d-flex align-items-center">
                                    <img class="flex-shrink-0 me-3" src="img/icon/icon-07-primary.png" alt="">
                                    <h5 class="mb-0">Expert Technician</h5>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="d-flex align-items-center">
                                    <img class="flex-shrink-0 me-3" src="img/icon/icon-09-primary.png" alt="">
                                    <h5 class="mb-0">Best Quality Services</h5>
                                </div>
                            </div>
                        </div>
                        <p class="mb-4">Our team of expert technicians is committed to providing you with the highest quality services. From installations to repairs, we ensure your heating and cooling systems are in top condition.</p>
                        <P class="mb-4">“We take great pride in being the trusted choice in ac service, over 5,000 homeowners.” Our commitment to excellence, dependability, and customer satisfaction has earned us the trust of our community. Join our growing family of delighted customers and enjoy dependable service.”</P>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-3">
                        <div class="col-6 text-end">
                            <img class="img-fluid w-75 wow zoomIn" data-wow-delay="0.1s" src="img/about-1.jpg" style="margin-top: 25%;">
                        </div>
                        <div class="col-6 text-start">
                            <img class="img-fluid w-100 wow zoomIn" data-wow-delay="0.3s" src="img/about-2.jpg">
                        </div>
                        <div class="col-6 text-end">
                            <img class="img-fluid w-50 wow zoomIn" data-wow-delay="0.5s" src="img/about-3.jpg">
                        </div>
                        <div class="col-6 text-start">
                            <img class="img-fluid w-75 wow zoomIn" data-wow-delay="0.7s" src="img/about-4.jpg">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Facts Start -->
    <div class="container-fluid facts my-5 py-5" data-parallax="scroll" data-image-src="img/carousel-1.jpg">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.1s">
                    <h1 class="display-4 text-white" data-toggle="counter-up">870</h1>
                    <span class="text-primary">Happy Clients</span>
                </div>
                <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.3s">
                    <h1 class="display-4 text-white" data-toggle="counter-up">915</h1>
                    <span class="text-primary">Recent Work</span>
                </div>
                <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.5s">
                    <h1 class="display-4 text-white" data-toggle="counter-up">415</h1>
                    <span class="text-primary">AC Installation</span>
                </div>
                <div class="col-sm-6 col-lg-3 wow fadeIn" data-wow-delay="0.7s">
                    <h1 class="display-4 text-white" data-toggle="counter-up">05</h1>
                    <span class="text-primary">Team Members</span>
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->


    <!-- Features Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h1 class="display-6 mb-5">Few Reasons Why People Choosing Us!</h1>
                    <p class="mb-5">At Freedom AirCon we understand why customers choose us over others. Here are a few reasons why:</p>
                    <div class="d-flex mb-5">
                        <div class="flex-shrink-0 btn-square bg-primary rounded-circle" style="width: 90px; height: 90px;">
                            <img class="img-fluid" src="img/icon/icon-08-light.png" alt="">
                        </div>
                        <div class="ms-4">
                            <h5 class="mb-3">Trusted Service Center</h5>
                            <span>When it comes to your HVAC needs, trust is paramount. Our service center has built a reputation for reliability and excellence.</span>
                        </div>
                    </div>
                    <div class="d-flex mb-5">
                        <div class="flex-shrink-0 btn-square bg-primary rounded-circle" style="width: 90px; height: 90px;">
                            <img class="img-fluid" src="img/icon/icon-10-light.png" alt="">
                        </div>
                        <div class="ms-4">
                            <h5 class="mb-3">Reasonable Price</h5>
                            <span>We believe that quality service shouldn't break the bank. That's why we offer competitive and transparent pricing for all our services. With us, you can enjoy top-notch HVAC solutions without worrying about exorbitant costs.</span>
                        </div>
                    </div>
                    <div class="d-flex mb-0">
                        <div class="flex-shrink-0 btn-square bg-primary rounded-circle" style="width: 90px; height: 90px;">
                            <img class="img-fluid" src="img/icon/icon-06-light.png" alt="">
                        </div>
                        <div class="ms-4">
                            <h5 class="mb-3">24/7 Supports</h5>
                            <span>HVAC emergencies can happen anytime, day or night. That's why we provide round-the-clock support to address your urgent needs. Whether it's a sudden breakdown or an unexpected issue, our team is here to help whenever you need us.</span>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Features End -->


    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-6 mb-5">We Provide professional AC Services</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item">
                        <img class="img-fluid" src="img/service-1.jpg" alt=""   style="width: auto; height: 300px;">
                        <div class="d-flex align-items-center bg-light">
                            <div class="service-icon flex-shrink-0 bg-primary">
                                <img class="img-fluid" src="img/icon/icon-01-light.png" alt="">
                            </div>
                            <a class="h4 mx-4 mb-0" href="acinstallation.php">AC Installation</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item">
                        <img class="img-fluid" src="img/service-6.jpg" alt=""  style="width: 500px; height: 300px;">
                        <div class="d-flex align-items-center bg-light">
                            <div class="service-icon flex-shrink-0 bg-primary">
                                <img class="img-fluid" src="img/icon/icon-06-light.png" alt="">
                            </div>
                            <a class="h4 mx-4 mb-0" href="acmain.php">Complete AC maintenance</a>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item">
                        <img class="img-fluid" src="img/service-3.jpg" alt=""   style="width: 500px; height: 300px;">
                        <div class="d-flex align-items-center bg-light">
                            <div class="service-icon flex-shrink-0 bg-primary">
                                <img class="img-fluid" src="img/icon/icon-08-light.png" alt="">
                            </div>
                            <a class="h4 mx-4 mb-0" href="washingrepair.php">WashingMachine Repair</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item">
                        <img class="img-fluid" src="img/service-8.jpg" alt=""   style="width: 500px; height: 300px;">
                        <div class="d-flex align-items-center bg-light">
                            <div class="service-icon flex-shrink-0 bg-primary">
                                <img class="img-fluid" src="img/icon/icon-04-light.png" alt="">
                            </div>
                            <a class="h4 mx-4 mb-0" href="watercooler.php">WaterCooler Repair</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item">
                        <img class="img-fluid" src="img/service-4.jpg" alt=""  style="width: 500px; height: 300px;">
                        <div class="d-flex align-items-center bg-light">
                            <div class="service-icon flex-shrink-0 bg-primary">
                                <img class="img-fluid" src="img/icon/icon-09-light.png" alt="">
                            </div>
                            <a class="h4 mx-4 mb-0" href="electric.php">Electric & Plumber Work</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item">
                        <img class="img-fluid" src="img/service-7.jpg" alt=""   style="width: auto; height: 300px;">
                        <div class="d-flex align-items-center bg-light">
                            <div class="service-icon flex-shrink-0 bg-primary">
                                <img class="img-fluid" src="img/icon/icon-07-light.png" alt="">
                            </div>
                            <a class="h4 mx-4 mb-0" href="refrigrator.php">Refrigerator Repair</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="ac-service-container">
        <p>We service AC units from all manufacturers, including:</p>
        <div class="brand-logos">
            <!-- Add logo images here -->
            <img src="img/lg.png" alt="Brand 1">
            <img src="img/godrej.png" alt="Brand 2">
            <img src="img/hitachi.png" alt="Brand 3">
            <img src="img/samsung.png" alt="Brand 4">
            <img src="img/voltas.png" alt="Brand 6">
            <img src="img/mitsubishi.png" alt="Brand 7">
            <img src="img/daiken.png" alt="Brand 8">
        </div>
    </div>

    <!-- Quote Start -->
    <div class="container-fluid overflow-hidden my-5 px-lg-0">
        <div class="container quote px-lg-0">
            <div class="row g-0 mx-lg-0">
                <div class="col-lg-6 quote-text" data-parallax="scroll" data-image-src="img/carousel-1.jpg">
                    <div class="h-100 px-4 px-sm-5 ps-lg-0 wow fadeIn" data-wow-delay="0.1s">
                        <h1 class="text-white mb-4">For Individuals And Organisations</h1>
                        <p class="text-light mb-5">We cater to the needs of both individuals and organizations. Our services are tailored to meet the diverse requirements of our clients, ensuring satisfaction at every level.</p>
                        <a href="" class="align-self-start btn btn-primary py-3 px-5">More Details</a>
                    </div>
                </div>
                <div class="col-lg-6 quote-form" data-parallax="scroll" data-image-src="img/carousel-2.jpg">
                    <div class="h-100 px-4 px-sm-5 pe-lg-0 wow fadeIn" data-wow-delay="0.5s">
                        <div class="bg-white p-4 p-sm-5">
                            <form action="mail.php" method="post">
                            <div class="row g-3">
                                <div class="col-sm-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="gname" placeholder="Enter Your Name" name="name">
                                        <label for="gname">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="gmail" placeholder="Enter Your Email" name="email">
                                        <label for="gmail">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="cname" placeholder="Enter Your Mobile Number" name="phone">
                                        <label for="cname">Your Mobile</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" name="message" id="message" style="height: 80px"></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary py-3 px-5" type="submit" name="send">Get A Free Quote</button>
                                </div>
                            </div>
                         </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Quote End -->

    <!-- Testimonial Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-6 mb-5">What They Say About Our Services</h1>
            </div>
            <div class="row g-5">
                <div class="col-lg-3 d-none d-lg-block">
                    <div class="testimonial-left h-100">
                        <img class="img-fluid animated pulse infinite" src="img/testimonial-1.jpg" alt="">
                        <img class="img-fluid animated pulse infinite" src="img/testimonial-2.jpg" alt="">
                        <img class="img-fluid animated pulse infinite" src="img/testimonial-3.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                    <div class="owl-carousel testimonial-carousel">
                        <div class="testimonial-item text-center">
                            <img class="img-fluid mx-auto mb-4" src="img/testimonial-1.jpg" alt="">
                            <p class="fs-5">The AC service was prompt and effective, restoring my unit's performance, and the technician's professionalism was commendable.</p>
                            <h5>Sunita Agarwal</h5>
                            <span>Freedom Aircon is the most professional</span>
                        </div>
                        <div class="testimonial-item text-center">
                            <img class="img-fluid mx-auto mb-4" src="img/testimonial-2.jpg" alt="">
                            <p class="fs-5"> Freedom Aircon delivers quality at an affordable price. Efficient repairs, noticeable savings. Freedom Aircon AC Repair is fast, friendly, and fantastic. Our AC works like new, and we couldn't be happier.</p>
                            <h5>Rohit Sharma</h5>
                            <span>Freedom Aircon is the most professional</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 d-none d-lg-block">
                    <div class="testimonial-right h-100">
                        <img class="img-fluid animated pulse infinite" src="img/testimonial-1.jpg" alt="">
                        <img class="img-fluid animated pulse infinite" src="img/testimonial-2.jpg" alt="">
                        <img class="img-fluid animated pulse infinite" src="img/testimonial-3.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'common/footer.php'  ?>
</body>

</html>